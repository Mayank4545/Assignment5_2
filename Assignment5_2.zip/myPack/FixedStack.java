package myPack;

import java.util.Scanner;

public class FixedStack implements Stack{

	int size;
	int count;
	int option;

	public FixedStack(int size) {
		super();
		this.size = size;
	}

	@Override
	public void push(int i) {

		do{
			@SuppressWarnings("resource")
			Scanner s = new Scanner(System.in);
			System.out.println("Push a value into stack: ");
			s.nextInt();
			count++;
			do{					/*Ask for confirmation till user selects correct input */
				if (count <= size) {
					
					System.out.println("Want to continue ?");
					System.out.println("1 = Yes 2 = No");
					option = s.nextInt();
					if (option == 2) {
						count = size + 1;
					}
					
				}
			}while (!(option == 1 || option == 2));


		}while(count <= size);

		if (count > size && option != 2) { /*Stack exceeded its fixed size */
			pop();
		}
	}

	@Override
	public int pop() {
		System.out.println("Stack overflow"); /*Display message of stack overflow */
		return 0;
	}

}
