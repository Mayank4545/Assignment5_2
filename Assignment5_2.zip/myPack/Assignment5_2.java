package myPack;

import java.util.Scanner;

public class Assignment5_2 {

	public static void main(String[] args) {

		int size = 0;
		int stack;

		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);

		System.out.println("Select the type of Stack !");
		System.out.println("1 = Fixed Stack 2 = Variable Stack");
		stack = s.nextInt();

		if (stack == 1) {
			System.out.println("Set the size of Fixed stack : ");

			size = s.nextInt();

			System.out.println("Start of Fixed Stack");
			System.out.println();
			FixedStack fs = new FixedStack(size); /* Create object to call FixedStack */
			fs.push(0);			/*Push into FixedStack */
			System.out.println("End of Fixed Stack");
			
		}else if (stack == 2) {
			System.out.println();
			System.out.println("Start of Variable Stack");
			System.out.println();
			System.out.println("Set the size of Variable stack : ");
			size = s.nextInt();
			VariableStack vs = new VariableStack(size); /* Create object to call VariableStack */
			vs.push(0);			/*Push into VariableStack */
			System.out.println("End of Variable Stack");
		}
	}
}
