package myPack;

public interface Stack {
	
	public void push(int i);
	public int pop();

}
