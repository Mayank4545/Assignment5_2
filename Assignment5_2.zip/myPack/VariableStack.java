package myPack;

import java.util.Scanner;

public class VariableStack implements Stack{
	
	int size;
	int count;
	int option;
	
	public VariableStack(int size) {
		super();
		this.size = size;
	}
	
	@Override
	public void push(int i) {

		do{
			@SuppressWarnings("resource")
			Scanner s = new Scanner(System.in);
			System.out.println("Push a value into stack: ");
			s.nextInt();
			count++;
			do{					/*Ask for confirmation till user selects correct input */
				if (count <= size) {
					
					System.out.println("Want to continue ?");
					System.out.println("1 = Yes 2 = No");
					option = s.nextInt();
					if (option == 2) {
						count = size + 1;
					}
					
				}
			}while (!(option == 1 || option == 2));
			
			if (count > size && option != 2) { /* Size limit exceeded.Increase the size of VariableStack by 5 */
				pop();
			}

		}while(option != 2);

		if (count > size && option != 2) { /* Size limit exceeded.Increase the size of VariableStack by 5 */
			pop();
		}	
	}

	@Override
	public int pop() {  /* Increase the size of VariableStack by 5 */
		size = size + 5;
		System.out.println("New size of stack increased to : " + size);
		
		return 0;
	}

}
